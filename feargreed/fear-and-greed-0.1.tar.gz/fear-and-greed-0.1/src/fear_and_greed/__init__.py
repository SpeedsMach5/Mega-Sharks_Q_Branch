from .cnn import FearGreedIndex, get

__version__ = "0.1"
